package com.example.diceapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private RadioGroup choiceDice;
    private RadioButton[] radioButtons;
    private Button throwDice;
    private ImageView[] diceImages;
    private Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        choiceDice = findViewById(R.id.choiceDice);
        throwDice = findViewById(R.id.throwDice);
        random = new Random();

        diceImages = new ImageView[]{
                findViewById(R.id.diceImage),
                findViewById(R.id.diceImage2),
                findViewById(R.id.diceImage3),
                findViewById(R.id.diceImage4),
                findViewById(R.id.diceImage5),
                findViewById(R.id.diceImage6)
        };

        radioButtons = new RadioButton[]{
                findViewById(R.id.dice_one),
                findViewById(R.id.dice_two),
                findViewById(R.id.dice_three),
                findViewById(R.id.dice_four),
                findViewById(R.id.dice_five),
                findViewById(R.id.dice_six)
        };

        choiceDice.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
                int selectedRadioButtonIndex = -1;
                for (int i = 0; i < radioButtons.length; i++) {
                    if (radioButtons[i].getId() == checkedId) {
                        selectedRadioButtonIndex = i;
                        break;
                    }
                }

                for (int i = 0; i < diceImages.length; i++) {
                    diceImages[i].setVisibility(i <= selectedRadioButtonIndex ? View.VISIBLE : View.INVISIBLE);
                }
            }
        });

        throwDice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < diceImages.length; i++) {
                    int numberOfDice = random.nextInt(6) + 1;
                    setDiceImageResource(diceImages[i], numberOfDice);
                }
            }
        });
    }

    private void setDiceImageResource(ImageView imageView, int diceValue) {
        int[] drawableResources = {
                R.drawable.dice1,
                R.drawable.dice2,
                R.drawable.dice3,
                R.drawable.dice4,
                R.drawable.dice5,
                R.drawable.dice6
        };

        imageView.setImageResource(drawableResources[diceValue - 1]);
    }
}
