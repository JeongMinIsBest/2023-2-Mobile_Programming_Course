package com.example.samplethreadanimation;

public class SampleThreadAnimation {
}
